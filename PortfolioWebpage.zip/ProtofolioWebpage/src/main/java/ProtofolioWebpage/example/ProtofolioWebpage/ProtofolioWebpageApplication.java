package ProtofolioWebpage.example.ProtofolioWebpage;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ProtofolioWebpageApplication {

	public static void main(String[] args) {
		SpringApplication.run(ProtofolioWebpageApplication.class, args);
	}

}
